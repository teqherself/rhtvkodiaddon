import xbmcaddon

MainBase = 'https://goo.gl/UHxdoU'
addon = xbmcaddon.Addon('plugin.video.ReelHouseTV')
